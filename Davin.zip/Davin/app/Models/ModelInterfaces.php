<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelInterfaces extends Model
{
	public function bestSeller()
	{
		return $this->db->table('BestSeller')
		->join('kue', 'BestSeller.idKue = kue.idKue')
		->orderBy('bestSeller.idKue', 'DESC')
		->limit(4)
		->get()
		->getResultArray();
	}
	public function bestSellerNoLimit()
	{
		return $this->db->table('BestSeller')
		->join('kue', 'BestSeller.idKue = kue.idKue')
		->orderBy('bestSeller.idKue', 'DESC')
		->get()
		->getResultArray();
	}
	public function kue()
	{
		return $this->db->table('kue')
		->orderBy('idKue', 'DESC')
		->limit(12)
		->get()
		->getResultArray();
	}
	public function kueNoLimit()
	{
		return $this->db->table('kue')
		->orderBy('idKue', 'DESC')
		->get()
		->getResultArray();
	}
	public function kontak()
	{
		return $this->db->table('kontak')
		->orderBy('idKontak', 'DESC')
		->get()
		->getResultArray();
	}
}