<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelKue extends Model
{
	public function kue()
	{
		return $this->db->table('kue')
		->orderBy('idKue', 'DESC')
		->get()
		->getResultArray();
	}
	public function insertData($data)
	{
		$this->db->table('kue')->insert($data);
	}
	public function detailData($idKue)
	{
		return $this->db->table('kue')
		->where('idKue', $idKue)
		->get()
		->getRowArray();
	}
	public function editData($data)
	{
		$this->db->table('kue')
		->where('idKue', $data['idKue'])
		->update($data);
	}
	public function deleteData($data)
	{
		$this->db->table('kue')
		->where('idKue', $data['idKue'])
		->delete($data);
	}
}