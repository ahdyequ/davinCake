<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelUser extends Model
{
	public function getAllData()
	{
		return $this->db->table('users')
		->orderBy('idUser', 'DESC')
		->get()
		->getResultArray();
	}
    public function detailData($idUser)
    {
        return $this->db->table('users')
            ->where('idUser', $idUser)
            ->get()
            ->getRowArray();
    }
	public function insertData($data)
	{
		$this->db->table('users')->insert($data);
	}
    public function editData($data)
    {
        $this->db->table('users')
        ->where('idUser', $data['idUser'])
        ->update($data);
    }
    public function deleteData($data)
    {
        $this->db->table('users')
        ->where('idUser', $data['idUser'])
        ->delete($data);
    }
}