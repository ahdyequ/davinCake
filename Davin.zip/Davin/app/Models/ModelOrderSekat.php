<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelOrderSekat extends Model
{
	public function getAllData()
	{
		return $this->db->table('orderSekat')
        ->join('sekat', 'orderSekat.idSekat = sekat.idSekat')
		->orderBy('idOrder', 'DESC')
		->get()
		->getResultArray();
	}
    public function detailData($idOrder)
    {
        return $this->db->table('orderSekat')
            ->where('idOrder', $idOrder)
            ->get()
            ->getRowArray();
    }
	public function insertData($data)
	{
		$this->db->table('orderSekat')->insert($data);
	}
    public function editData($data)
    {
        $this->db->table('orderSekat')
        ->where('idOrder', $data['idOrder'])
        ->update($data);
    }
    public function deleteData($data)
    {
        $this->db->table('orderSekat')
        ->where('idOrder', $data['idOrder'])
        ->delete($data);
    }
}