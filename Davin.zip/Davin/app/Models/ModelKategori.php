<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelKategori extends Model
{


	// ====== BASTSELLER START ======
	public function bestSeller()
	{
		return $this->db->table('bestSeller')
		->join('kue', 'BestSeller.idKue = kue.idKue')
		->orderBy('bestSeller.idKue', 'DESC')
		->get()
		->getResultArray();
	}
	public function detailBestSeller($idBestSeller)
    {
        return $this->db->table('bestSeller')
            ->where('idBestSeller', $idBestSeller)
            ->get()
            ->getRowArray();
    }
	public function insertBestSeller($data)
	{
		$this->db->table('bestSeller')->insert($data);
	}
	public function deleteBestSeller($data)
    {
        $this->db->table('bestSeller')
        ->where('idBestSeller', $data['idBestSeller'])
        ->delete($data);
    }
    // ====== BASTSELLER ENDS ======


    // ====== HAMPERS START ======
    public function hampers()
	{
		return $this->db->table('hampers')
		->orderBy('idHampers', 'DESC')
		->get()
		->getResultArray();
	}
	public function detailHampers($idHampers)
    {
        return $this->db->table('hampers')
            ->where('idHampers', $idHampers)
            ->get()
            ->getRowArray();
    }
    public function insertHampers($data)
	{
		$this->db->table('hampers')->insert($data);
	}
	public function updateHampers($data)
    {
        $this->db->table('hampers')
        ->where('idHampers', $data['idHampers'])
        ->update($data);
    }
	public function deleteHampers($data)
    {
        $this->db->table('hampers')
        ->where('idHampers', $data['idHampers'])
        ->delete($data);
    }
    // ====== HAMPERS START ======


    // ====== SEKAT START ======
    public function sekat()
	{
		return $this->db->table('sekat')
		->orderBy('idSekat', 'DESC')
		->get()
		->getResultArray();
	}
	public function detailSekat($idSekat)
    {
        return $this->db->table('sekat')
            ->where('idSekat', $idSekat)
            ->get()
            ->getRowArray();
    }
    public function insertSekat($data)
	{
		$this->db->table('sekat')->insert($data);
	}
	public function updateSekat($data)
    {
        $this->db->table('sekat')
        ->where('idSekat', $data['idSekat'])
        ->update($data);
    }
	public function deleteSekat($data)
    {
        $this->db->table('sekat')
        ->where('idSekat', $data['idSekat'])
        ->delete($data);
    }
    // ====== SEKAT START ======
}