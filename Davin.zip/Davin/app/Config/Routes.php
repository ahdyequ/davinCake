<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */


// ====== INTERFACES ======
$routes->get('/', 'Home::index');
$routes->get('bestSeller', 'Home::bestSeller');
$routes->get('allKue', 'Home::allKue');


// ====== ADMIN ======
$routes->get('dashboard', 'Dashboard::index');
// kategori
$routes->get('kategori', 'Kategori::index');
// kategori bastseller
$routes->post('kategori/insertBestSeller', 'Kategori::insertBestSeller/$1');
$routes->get('kategori/deleteBestSeller/(:num)', 'Kategori::deleteBestSeller/$1');
// Kategori hampers
$routes->post('kategori/insertHampers', 'Kategori::insertHampers/$1');
$routes->post('kategori/updateHampers/(:num)', 'Kategori::updateHampers/$1');
$routes->get('kategori/deleteHampers/(:num)', 'Kategori::deleteHampers/$1');
// Kategori Sekat
$routes->post('kategori/insertSekat', 'Kategori::insertSekat/$1');
$routes->post('kategori/updateSekat/(:num)', 'Kategori::updateSekat/$1');
$routes->get('kategori/deleteSekat/(:num)', 'Kategori::deleteSekat/$1');
// User
$routes->get('user', 'User::index');
$routes->post('user/insertData', 'User::insertData/$1');
$routes->post('user/updateData/(:num)', 'User::updateData/$1');
$routes->get('user/deleteData/(:num)', 'User::deleteData/$1');
// Kue
$routes->get('kue', 'Kue::index');
$routes->post('kue/insertData', 'Kue::insertData/$1');
$routes->post('kue/updateData/(:num)', 'Kue::updateData/$1');
$routes->get('kue/deleteData/(:num)', 'Kue::deleteData/$1');


// ====== RESELLER ======
$routes->get('orderSekat', 'OrderSekat::index');
$routes->post('orderSekat/insertData', 'OrderSekat::insertData/$1');
$routes->post('orderSekat/updateData/(:num)', 'OrderSekat::updateData/$1');
$routes->get('orderSekat/deleteData/(:num)', 'OrderSekat::deleteData/$1');