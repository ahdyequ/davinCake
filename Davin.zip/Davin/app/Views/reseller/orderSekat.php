<?= $this->extend('template') ?>
<?= $this->section('content') ?>

<div class="row">


	<!--====== ALERT START ======-->
	<?php
	if (session()->getFlashdata('tambah')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('tambah');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('edit')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('edit');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('delete')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('delete');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	?>
	<!--====== ALERT ENDS ======-->


	<!--====== ORDER START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 col-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?></h4>
				</div>
				<div class="col-lg-6 col-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addOrder"><i class="fa fa-plus"></i> Tambah</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Client</th>
								<th>Tgl Order</th>
								<th>Sekat</th>
								<th>Harga</th>
								<th>Status</th>
								<th>Aksis</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<?php $no = 1;
								foreach ($orderSekat as $key => $value) { ?>
									<th><?= $no++; ?></th>
									<td>
										<div>
											<span>Nama</span> : <strong><?= $value['nama'] ?></strong> 
										</div>
										<div>
											<span>Alamat</span> : <strong><?= $value['alamat'] ?></strong> 
										</div>
										<div>
											<span>No Hp/Wa</span> : <strong><?= $value['noHp'] ?></strong> 
										</div>
									</td>
									<td>
										<div>
											<span>Tgl Order</span> : <strong><?= $value['tglOrder'] ?></strong> 
										</div>
									</td>
									<td><?= $value['kategori'] ?></td>
									<td><?= $value['harga'] ?></td>
									<td><?= $value['status'] ?></td>
									<td>
										<div class="d-flex">
											<button type="button" class="btn btn-success shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#update<?= $value['idOrder'] ?>"><i class="fas fa-pencil-alt"></i></button>
											<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#delete<?= $value['idOrder'] ?>"><i class="fa fa-trash"></i></button>
											<a href="whatsapp://send?text=*NOTA%20ORDER%20DAVIN%20CAKE%20%26%20COOKIES*%0A%0ANo%20Order%20%3A%0A<?= $value['idOrder'] ?>%0A<?= $value['kategori'] ?>%0A%0APelanggan%20%3A%0A<?= $value['nama'] ?>%0A%0ATanggal%20Order%20%3A%0A<?= $value['tglOrder'] ?>%0A%0AStatus%20%3A%0A<?= $value['status'] ?>%0A%0AHarga%20%3A%0A<?= $value['harga'] ?>&phone=<?= $value['noHp'] ?>" class="btn btn-danger shadow btn-xs sharp me-1"><i class="far fa-comment-alt"></i></a>
										</div>	
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!--====== ORDER ENDS ======-->


	<!--====== ADD ORDER START ======-->
	<div class="modal fade" id="addOrder">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				
				<?php echo form_open_multipart('orderSekat/insertData') ?>
				<div class="modal-body">
					<input type="text" name="idReseller" class="form-control" value="3">
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Nama</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="nama" class="form-control" placeholder="Masukan nama lengkap." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Sekat</label>
						<div class="col-sm-9 input-primary">
							<select name="idSekat" class="default-select  form-control wide" required>
								<option value="">==== Pilih Sekat ====</option>
								<?php foreach ($sekat as $key => $value): ?>
									<option value="<?= $value['idSekat'] ?>"><?= $value['kategori'] ?></option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Alamat</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="alamat" class="form-control" placeholder="Masukan alamat pelanggan." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">No Hp</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="noHp" class="form-control" placeholder="Masukan No Hp pelanggan." required>
							<span class="text-danger">Dengan mencantumkan format negara contoh : +62821********</span>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Status</label>
						<div class="col-sm-9 input-primary">
							<select name="status" class="default-select  form-control wide" required>
								<option value="">- Pilih Status -</option>
								<option value="Ngantri">Ngantri</option>
								<option value="Selesai">Selesai</option>
								<option value="Ditunda">Ditunda</option>
							</select>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah user</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--====== ADD ORDER ENDS ======-->


	<!--====== UPDATE ORDER START ======-->

	<!--====== UPDATE ORDER ENDS ======-->


	<!--====== DELETE ORDER START ======-->

	<!--====== DELETE ORDER ENDS ======-->


</div>


<?= $this->endSection() ?>