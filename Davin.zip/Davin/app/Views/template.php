<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title ?> | <?= $subtitle ?></title>
    <!--====== Select css ======-->
    <link href="<?= base_url() ?>vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url() ?>vendor/select2/css/select2.min.css">
    <link href="<?= base_url() ?>vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="<?= base_url() ?>vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url() ?>/vendor/nouislider/nouislider.min.css">
    <link href="<?= base_url() ?>vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="<?= base_url() ?>vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>css/style.css" rel="stylesheet">
</head>
<body>


    <!--====== PRELOADER PART START ======-->
    <div id="preloader">
        <div class="lds-ripple">
            <div></div>
            <div></div>
        </div>
    </div>
    <!--====== PRELOADER ENDS START ======-->


    <!--====== MAIN WRAPPER START ======-->
    <div id="main-wrapper">


        <!--====== NAV HEADER START ======-->
        <div class="nav-header">
            <a href="index.html" class="brand-logo">
                <img src="<?= base_url() ?>/images/logo/logo.jpg" width="50" alt="">
                <div class="brand-title">
                    <h2>Davin.</h2>
                    <span class="brand-sub-title">cake & cookies</span>
                </div>
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--====== NAV HEADER ENDS ======-->


        <!--====== HEADER START ======-->
        <div class="header border-bottom">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
                                <?= $subtitle ?>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!--====== HEADER ENDS ======-->


        <!--====== SLIDEBAR START ======-->
        <div class="dlabnav">
            <div class="dlabnav-scroll">
                <ul class="metismenu" id="menu">
                    <li>
                        <a href="<?= base_url('/')?>" class="" aria-expanded="false">
                            <i class="fas fa-user"></i>
                            <span class="nav-text">HOME</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('bestSeller')?>" class="" aria-expanded="false">
                            <i class="fas fa-user"></i>
                            <span class="nav-text">BEST SELLER</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('allKue')?>" class="" aria-expanded="false">
                            <i class="fas fa-user"></i>
                            <span class="nav-text">SEMUA KUE</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('kontak')?>" class="" aria-expanded="false">
                            <i class="fas fa-user"></i>
                            <span class="nav-text">KONTAK ADMIN</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('reseller')?>" class="" aria-expanded="false">
                            <i class="fas fa-user"></i>
                            <span class="nav-text">RESELLER</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="" aria-expanded="false">
                            <span class="nav-text">==========================</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('dashboard')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">DASHBOARD</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('kategori')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">KATEGORI</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('user')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">USER</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('kue')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">KUE</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="" aria-expanded="false">
                            <span class="nav-text">==========================</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('dashboardReseller')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">DASHBOARD</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('orderSekat')?>" class="" aria-expanded="false">
                            <i class="fas fa-home"></i>
                            <span class="nav-text">ORDER SEKAT</span>
                        </a>
                    </li>
                </ul>
                <div class="copyright">
                    <p><strong>Follow Instagram ahdyeu</strong> © 2024 All Rights Reserved</p>
                </div>
            </div>
        </div>
        <!--====== SLIDEBAR ENDS ======-->


        <!--====== CONTENT START ======-->
        <div class="content-body">
            <div class="container-fluid">
                <?= $this->renderSection('content') ?>
            </div>
        </div>
        <!--====== CONTENT ENDS ======-->


        <!--====== FOOTER START ======-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="../index.htm" target="_blank">Equ</a> 2024</p>
            </div>
        </div>
        <!--====== FOOTER ENDS ======-->


    </div>
    <!--====== MAIN WRAPPER ENDS ======-->


    <!--====== SCRIPT START ======-->
    <script src="<?= base_url() ?>vendor/sweetalert2/dist/sweetalert2.min.js"></script>
    <script src="<?= base_url() ?>vendor/global/global.min.js"></script>
    <script src="<?= base_url() ?>vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
    <script src="<?= base_url() ?>vendor/select2/js/select2.full.min.js"></script>
    <script src="<?= base_url() ?>js/plugins-init/select2-init.js"></script>
    <script src="<?= base_url() ?>vendor/chart.js/Chart.bundle.min.js"></script>

    <!-- Apex Chart -->
    <script src="<?= base_url() ?>vendor/apexchart/apexchart.js"></script>

    <script src="<?= base_url() ?>vendor/chart.js/Chart.bundle.min.js"></script>

    <!-- Chart piety plugin files -->
    <script src="<?= base_url() ?>vendor/peity/jquery.peity.min.js"></script>
    <!-- Dashboard 1 -->
    <script src="<?= base_url() ?>js/dashboard/dashboard-1.js"></script>

    <script src="<?= base_url() ?>vendor/owl-carousel/owl.carousel.js"></script>

    <script src="<?= base_url() ?>js/custom.min.js"></script>
    <script src="<?= base_url() ?>js/dlabnav-init.js"></script>
    <script src="<?= base_url() ?>js/demo.js"></script>
    <script>
        window.setTimeout(function() {
            $(".alert").fadeTo(500, 0).slideUp(500, function() {
                $($this).remove();
            });
        }, 4000);
    </script>
    <script>
        function cardsCenter()
        {

            /*  testimonial one function by = owl.carousel.js */



            jQuery('.card-slider').owlCarousel({
                loop:true,
                margin:0,
                nav:true,
                //center:true,
                slideSpeed: 3000,
                paginationSpeed: 3000,
                dots: true,
                navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
                responsive:{
                    0:{
                        items:1
                    },
                    576:{
                        items:1
                    },  
                    800:{
                        items:1
                    },          
                    991:{
                        items:1
                    },
                    1200:{
                        items:1
                    },
                    1600:{
                        items:1
                    }
                }
            })
        }

        jQuery(window).on('load',function(){
            setTimeout(function(){
                cardsCenter();
            }, 1000); 
        });

    </script>
    <!--====== SCRIPT ENDS ======-->
</body>
</html>