<?= $this->extend('template') ?>
<?= $this->section('content') ?>


<!--====== BAST SELLER START ======-->
<div class="row">
	<div class="chat-bx d-flex active mb-2 justify-content-between align-items-center flex-wrap">
		<h3 class="text-primary">Semua Kue</h3>
	</div>
	<?php foreach ($allKue as $key => $value) { ?>
		<div class=" mt-4 col-xl-3 col-6">
			<div class="card">
				<div class="card-body">
					<div class="new-arrival-product">
						<div class="new-arrivals-img-contnent">
							<img class="img-fluid rounded" src="<?= base_url('images/kue/' . $value['fotoKue']) ?>" alt="">
						</div>
						<div class="new-arrival-content text-center mt-3">
							<h4><a href="ecom-product-detail.html"><?= $value['namaKue'] ?></a></h4>
							<div class="text-primary fs-18">TK | Rp <?php echo number_format($value['hargaTk'], 0, ",","."); ?></div>
							<div class="text-primary fs-18">TB | Rp <?php echo number_format($value['hargaTb'], 0, ",","."); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
</div>
<!--====== BAST SELLER ENDS ======-->


<?= $this->endSection() ?>