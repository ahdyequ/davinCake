<?= $this->extend('template') ?>
<?= $this->section('content') ?>


<div class="row">

	<!--====== HERO START ======-->
	<div class="chat-bx active mb-2 justify-content-between align-items-center flex-wrap">
		<div class="card tryal-gradient">
			<div class="card-body tryal row">
				<div class="col-xl-7 col-sm-6">
					<h2>Selamat datang di davin</h2>
					<span>cake and cookies </span>
					<a href="<?= base_url('semuaKue') ?>" class="btn btn-rounded  fs-18 font-w500">Lihat semua kue</a>
				</div>
			</div>
		</div>
	</div>
	<!--====== HERO ENDS ======-->


	<!--====== SERVICES START ======-->
	<div class="col-xl-3 col-3">
		<div class="widget-stat card">
			<div class="card-body">
				<img class="img-fluid" width="200px" src="<?= base_url() ?>images/icon/hp.png" alt="">
			</div>
		</div>
	</div>
	<div class="col-xl-3 col-3">
		<div class="card">
			<div class="card-body">
				<img class="img-fluid" width="200px" src="<?= base_url() ?>images/icon/pesan.png" alt="">
			</div>
		</div>
	</div>
	<div class="col-xl-3 col-3">
		<div class="card">
			<div class="card-body">
				<img class="img-fluid" width="200px" src="<?= base_url() ?>images/icon/terkirim.png" alt="">
			</div>
		</div>
	</div>
	<div class="col-xl-3 col-3">
		<div class="card">
			<div class="card-body">
				<img class="img-fluid" width="200px" src="<?= base_url() ?>images/icon/terima.png" alt="">
			</div>
		</div>
	</div>
	<!--====== SERVICES ENDS ======-->
	


	<!--====== BAST SELLER START ======-->
	<div class="chat-bx d-flex active mb-2 justify-content-between align-items-center flex-wrap">
		<h3 class="text-primary">Best seller</h3>
		<div class="text-center">
			<a href="<?= base_url('bastSeller') ?>" class="btn btn-primary">Lihat semua best seller <i class="fa fa-arrow-right"></i></a>
		</div>
	</div>
	<?php foreach ($bestSeller as $key => $value) { ?>
		<div class=" mt-4 col-xl-3 col-6">
			<div class="card">
				<div class="card-body">
					<div class="new-arrival-product">
						<div class="new-arrivals-img-contnent">
							<img class="img-fluid rounded" src="<?= base_url('images/kue/' . $value['fotoKue']) ?>" alt="">
						</div>
						<div class="new-arrival-content text-center mt-3">
							<h4><a href="ecom-product-detail.html"><?= $value['namaKue'] ?></a></h4>
							<div class="text-primary fs-18">TK | Rp <?php echo number_format($value['hargaTk'], 0, ",","."); ?></div>
							<div class="text-primary fs-18">TB | Rp <?php echo number_format($value['hargaTb'], 0, ",","."); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== BAST SELLER ENDS ======-->

	<!--====== BAST SELLER START ======-->
	<div class="chat-bx d-flex active mb-2 justify-content-between align-items-center flex-wrap">
		<h3 class="text-primary">Kue</h3>
		<div class="text-center">
			<a href="<?= base_url('allKue') ?>" class="btn btn-primary">Lihat semua kue <i class="fa fa-arrow-right"></i></a>
		</div>
	</div>
	<?php foreach ($kue as $key => $value) { ?>
		<div class="mt-4 col-xl-3 col-6">
			<div class="card">
				<div class="card-body">
					<div class="new-arrival-product">
						<div class="new-arrivals-img-contnent">
							<img class="img-fluid rounded" src="<?= base_url('images/kue/' . $value['fotoKue']) ?>" alt="">
						</div>
						<div class="new-arrival-content text-center mt-3">
							<h4><a href="ecom-product-detail.html"><?= $value['namaKue'] ?></a></h4>
							<div class="text-primary fs-18">TK | Rp <?php echo number_format($value['hargaTk'], 0, ",","."); ?></div>
							<div class="text-primary fs-18">TB | Rp <?php echo number_format($value['hargaTb'], 0, ",","."); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== BAST SELLER ENDS ======-->

	<!--====== BAST SELLER START ======-->
	<div class="chat-bx d-flex active mb-2 justify-content-between align-items-center flex-wrap">
		<h3 class="text-primary">Kontak</h3>
	</div>
	<?php foreach ($kontak as $key => $value) { ?>
		<div class="mt-4 col-xl-3 col-6 items">
			<div class="card contact-bx item-content">
				<div class="card-body user-profile">
					<div class="image-bx">
						<img src="<?= base_url('images/kontak/' . $value['fotoKontak']) ?>" alt="" class="rounded-circle">
					</div>
					<div class="media-body user-meta-info">
						<h6 class="fs-18 font-w600 my-1"><a href="app-profile.html" class="text-black user-name" data-name="Alan Green"><?= $value['nama'] ?></a></h6>
						<ul>
							<li><a href="tel://<?= $value['nohp'] ?>"><i class="fas fa-phone-alt"></i></a></li>
							<li><a href="whatsapp://send?text=<?= $value['pesan'] ?>&phone=<?= $value['wa'] ?>"><i class="far fa-comment-alt"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== BAST SELLER ENDS ======-->


</div>


<?= $this->endSection() ?>