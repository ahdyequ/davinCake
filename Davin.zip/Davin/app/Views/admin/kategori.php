<?= $this->extend('template') ?>
<?= $this->section('content') ?>


<div class="row">


	<!--====== ALERT START ======-->
	<?php
	if (session()->getFlashdata('tambah')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('tambah');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('edit')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('edit');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('delete')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('delete');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	?>
	<!--====== ALERT ENDS ======-->


	<!--====== BASTSELLER START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?> Best Seller</h4>
				</div>
				<div class="col-lg-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addBestSeller"><i class="fa fa-plus"></i> Tambah best seller</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Kue</th>
								<th>Harga Toples Kecil</th>
								<th>Harga Toples Besar</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1;
							foreach ($bestSeller as $key => $value) { ?>
								<tr>
									<td><?= $no++; ?></td>
									<td>
										<img class="img-fluid rounded" width="56" src="<?= base_url('images/kue/' . $value['fotoKue']) ?>" alt="">
										<?= $value['namaKue'] ?>
									</td>
									<td>Rp <?php echo number_format($value['hargaTk'], 0, ",","."); ?></td>
									<td>Rp <?php echo number_format($value['hargaTb'], 0, ",","."); ?></td>
									<td>
										<div class="d-flex">
											<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#deleteBestSeller<?= $value['idBestSeller'] ?>"><i class="fa fa-trash"></i></button>
										</div>	
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>


	<!--====== ADD BASTSELLER START ======-->
	<div class="modal fade" id="addBestSeller">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?> Best Seller</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<?php echo form_open_multipart('kategori/insertBestSeller') ?>
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label col-form-label-lg">Nama kue</label>
						<div class="col-sm-9 input-primary">
							<select class="multi-select" name="idKue[]" multiple="multiple">
								<?php foreach($kue as $key => $value) { ?>
									<option value="<?= $value['idKue'] ?>"><?= $value['namaKue'] ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--====== ADD BASTSELLER END ======-->


	<!--====== DELETE BASTSELLER START ======-->
	<?php foreach ($bestSeller as $key => $value) { ?>
		<div class="modal fade" id="deleteBestSeller<?= $value['idBestSeller'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-body text-center">
						<div>
							<svg viewbox="0 0 24 24" width="80" height="80" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mb-2 text-warning"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
						</div>
						<h2>Apakah anda ingin menghapus Best Seller <strong><?= $value['namaKue'] ?></strong></h2>
						<div class="mt-4">
							<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
							<a href="<?= base_url('kategori/deleteBestSeller/' . $value['idBestSeller']) ?>" class="btn btn-primary">Hapus</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== DELETE BASTSELLER START ======-->


	<!--====== BASTSELLER ENDS ======-->
	

	<!--====== HAMPERS START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?> Hampers</h4>
				</div>
				<div class="col-lg-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addHampers"><i class="fa fa-plus"></i> Tambah Hampers</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Kategori</th>
								<th>Jumlah</th>
								<th>Massa(g)</th>
								<th>Harga</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1;
							foreach ($hampers as $key => $value) { ?>
								<tr>
									<td><?= $no++; ?></td>
									<td><?= $value['kategori'] ?></td>
									<td><?= $value['jumlah'] ?></td>
									<td><?= $value['massa'] ?></td>
									<td>Rp <?php echo number_format($value['harga'], 0, ",","."); ?></td>
									<td>
										<div class="d-flex">
											<button type="button" class="btn btn-primary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#updateHampers<?= $value['idHampers'] ?>"><i class="fa fa-edit"></i></button>
											<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#deleteHampers<?= $value['idHampers'] ?>"><i class="fa fa-trash"></i></button>
										</div>	
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>


	<!--====== ADD HAMPERS START ======-->
	<div class="modal fade" id="addHampers">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?> Hampers</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<?php echo form_open_multipart('kategori/insertHampers') ?>
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Kategori</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="kategori" class="form-control" placeholder="Masukan Kategori." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Jumlah Toples</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="jumlah" class="form-control" placeholder="Masukan jumlah(1-100).">
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">massa(Gram)</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="massa" class="form-control" placeholder="Masukan berat kue.">
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">harga</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="harga" class="form-control" placeholder="Masukan harga." required>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah Kue</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--====== ADD HAMPERS START ======-->


	<!--====== UPDATE HAMPERS START ======-->
	<?php foreach ($hampers as $key => $value) { ?>
		<div class="modal fade" id="updateHampers<?= $value['idHampers'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Form Edit <?= $subtitle ?> Hampers</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal">
						</button>
					</div>
					<?php echo form_open_multipart('kategori/updateHampers/' . $value['idHampers']) ?>
					<div class="modal-body">
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Kategori</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="kategori" class="form-control" value="<?= $value['kategori'] ?>">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Jumlah Toples</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="jumlah" class="form-control" value="<?= $value['jumlah'] ?>">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">massa(Gram)</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="massa" class="form-control" value="<?= $value['massa'] ?>">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">harga</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="harga" class="form-control" value="<?= $value['harga'] ?>">
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
						<button type="submit" class="btn btn-primary">Edit Hampers</button>
					</div>
					<?php echo form_close() ?>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== UPDATE HAMPERS START ======-->


	<!--====== DELETE HAMPERS START ======-->
	<?php foreach ($hampers as $key => $value) { ?>
		<div class="modal fade" id="deleteHampers<?= $value['idHampers'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-body text-center">
						<div>
							<svg viewbox="0 0 24 24" width="80" height="80" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mb-2 text-warning"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
						</div>
						<h2>Apakah anda ingin menghapus kategori <strong><?= $value['kategori'] ?> <?= $value['jumlah'] ?> Toples <?= $value['massa'] ?>g</strong></h2>
						<div class="mt-4">
							<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
							<a href="<?= base_url('kategori/deleteHampers/' . $value['idHampers']) ?>" class="btn btn-primary">Hapus</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== DELETE HAMPERS START ======-->


	<!--====== HAMPERS ENDS ======-->


	<!--====== SEKAT START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?> Sekat</h4>
				</div>
				<div class="col-lg-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addSekat"><i class="fa fa-plus"></i> Tambah Sekat</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Kategori</th>
								<th>Nama kue</th>
								<th>Harga</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1;
							foreach ($sekat as $key => $value) { ?>
								<tr>
									<td><?= $no++; ?></td>
									<td><?= $value['kategori'] ?></td>
									<td><?= $value['namaKue'] ?></td>
									<td>Rp <?php echo number_format($value['harga'], 0, ",","."); ?></td>
									<td width="200px">
										<button type="button" class="btn btn-warning shadow  btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#updateSekat<?= $value['idSekat'] ?>"><i class="fas fa-pencil-alt"></i></button>
										<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#deleteSekat<?= $value['idSekat'] ?>"><i class="fa fa-trash"></i></button>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!--====== SEKAT START ======-->


	<!--====== ADD SEKAT START ======-->
	<div class="modal fade" id="addSekat">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?> Sekat</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<?php echo form_open_multipart('kategori/insertSekat') ?>
				<div class="modal-body">
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Kategori</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="kategori" class="form-control" placeholder="Masukan Kategori." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Kue</label>
						<div class="col-sm-9 input-primary">
							<select class="multi-select" name="namaKue[]" multiple="multiple">
								<?php foreach($kue as $key => $value) { ?>
									<option value="<?= $value['namaKue'] ?>"><?= $value['namaKue'] ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">harga</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="harga" class="form-control" placeholder="Masukan harga." required>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah Kue</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--====== ADD SEKAT START ======-->


	<!--====== UPDATE SEKAT START ======-->
	<?php foreach ($sekat as $key => $value) { ?>
		<div class="modal fade" id="updateSekat<?= $value['idSekat'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Form Edit <?= $subtitle ?> Hampers</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal">
						</button>
					</div>
					<?php echo form_open_multipart('kategori/updateSekat/' . $value['idSekat']) ?>
					<div class="modal-body">
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Kategori</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="kategori" class="form-control" value="<?= $value['kategori'] ?>">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Kue</label>
							<div class="col-sm-9 input-primary">
								<select class="multi-select" name="namaKue[]" multiple="multiple">
									<?php foreach($kue as $key => $kues) { ?>
										<option value="<?= $kues['namaKue'] ?>"><?= $kues['namaKue'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">harga</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="harga" class="form-control" value="<?= $value['harga'] ?>">
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
						<button type="submit" class="btn btn-primary">Edit Sekat</button>
					</div>
					<?php echo form_close() ?>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== UPDATE SEKAT START ======-->


	<!--====== DELETE SEKAT START ======-->
	<?php foreach ($sekat as $key => $value) { ?>
		<div class="modal fade" id="deleteSekat<?= $value['idSekat'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-body text-center">
						<div>
							<svg viewbox="0 0 24 24" width="80" height="80" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mb-2 text-warning"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
						</div>
						<h2>Apakah anda ingin menghapus kategori <strong><?= $value['kategori'] ?> ini ?</strong></h2>
						<div class="mt-4">
							<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
							<a href="<?= base_url('kategori/deleteSekat/' . $value['idSekat']) ?>" class="btn btn-primary">Hapus</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== DELETE SEKAT START ======-->


	<!--====== SEKAT ENDS ======-->


</div>




<?= $this->endSection() ?>