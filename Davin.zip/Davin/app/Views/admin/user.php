<?= $this->extend('template') ?>
<?= $this->section('content') ?>


<div class="row">


	<!--====== ALERT START ======-->
	<?php
	if (session()->getFlashdata('tambah')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('tambah');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('edit')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('edit');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('delete')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('delete');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	?>
	<!--====== ALERT ENDS ======-->


	<!--====== USER START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 col-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?></h4>
				</div>
				<div class="col-lg-6 col-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addUser"><i class="fa fa-plus"></i> Tambah</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Pengguna</th>
								<th>Nama Lengkap</th>
								<th>Email</th>
								<th>Level</th>
								<th>Status</th>
								<th>Aksis</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<?php $no = 1;
								foreach ($user as $key => $value) { ?>
									<th><?= $no++; ?></th>
									<td>
										<img src="<?= base_url('images/user/' . $value['fotoUser']) ?>" height="70" width="70" class="rounded me-2 object-fit" alt="Gambar hilang |">
										@<?= $value['namaPengguna'] ?>
									</td>
									<td><?= $value['nama'] ?></td>
									<td>
										<?php if ($value['email'] == "user@gmail.com") { ?>
											<p class="text-muted">Belum di perbarui</p>
										<?php }else { ?>
											<?= $value['email'] ?>
										<?php } ?>
									</td>
									<td>
										<?php if ($value['level'] == 1) { ?>
											Admin
										<?php }else { ?>
											Reseller
										<?php } ?>
									</td>
									<td>
										<?php if ($value['status'] == 1) { ?>
											<span class="badge badge-success">Aktif</span>
										<?php }else { ?>
											<span class="badge badge-primary">Tidak Aktif</span>
										<?php } ?>
									</td>
									<td>
										<div class="d-flex">
											<button type="button" class="btn btn-success shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#updateUser<?= $value['idUser'] ?>"><i class="fas fa-pencil-alt"></i></button>
											<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#deleteUser<?= $value['idUser'] ?>"><i class="fa fa-trash"></i></button>
										</div>	
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!--====== USER ENDS ======-->


	<!--======ADD USER START ======-->
	<div class="modal fade" id="addUser">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				
				<?php echo form_open_multipart('user/insertData') ?>
				<div class="modal-body">
					<div class="input-group mb-3 input-primary">
						<span class="btn btn-primary btn-sm">Foto User</span>
						<div class="form-file">
							<input type="file" name="fotoUser" class="form-file-input form-control">
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Nama Pengguna</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="namaPengguna" class="form-control" placeholder="Masukan nama pengguna." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Nama Lengkap</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="nama" class="form-control" placeholder="Masukan nama lengkap." required>
						</div>
					</div>
					<input type="hidden" name="email" class="form-control" value="user@gmail.com">
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Level</label>
						<div class="col-sm-9 input-primary">
							<select name="level" class="default-select  form-control wide" required>
								<option value="">- Pilih Level -</option>
								<option value="1">admin</option>
								<option value="2">reseller</option>
							</select>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Status</label>
						<div class="col-sm-9 input-primary">
							<select name="status" class="default-select  form-control wide" required>
								<option value="">- Pilih Status -</option>
								<option value="1">aktif</option>
								<option value="2">tidak aktif</option>
							</select>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Kata Sandi</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="password" class="form-control" placeholder="Masukan kata sandi baru." required>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah user</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--======ADD USER ENDS ======-->


	<!--======UPDATE USER START ======-->
	<?php foreach ($user as $key => $value) { ?>
		<div class="modal fade" id="updateUser<?= $value['idUser'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Form tambah <?= $subtitle ?></h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal">
						</button>
					</div>
					<?php echo form_open_multipart('user/updateData/' . $value['idUser']) ?>
					<div class="modal-body">
						<div class="m-2 text-center">
							<img src="<?= base_url('images/user/' . $value['fotoUser']) ?>" height="150" width="150" class="rounded-circle object-fit">
						</div>
						<div class="input-group mb-3 input-primary">
							<span class="btn btn-primary btn-sm">Foto User</span>
							<div class="form-file">
								<input type="file" name="fotoUser" value="<?= base_url('images/user/' . $value['fotoUser']) ?>" class="form-file-input form-control">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Nama Pengguna</label>
							<div class="col-sm-9 input-primary">
								<input type="text" value="<?= $value['namaPengguna'] ?>" name="namaPengguna" class="form-control">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Nama Lengkap</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="nama" class="form-control" value="<?= $value['nama'] ?>">
							</div>
						</div>
						<input type="hidden" name="email" class="form-control" value="user@gmail.com">
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Level</label>
							<div class="col-sm-9 input-primary">
								<select name="level" class="default-select  form-control wide" required>
									<option <?php if ($value['level'] == '1')  echo 'selected'; ?> value="1"> Admin </option>
									<option <?php if ($value['level'] == '2')   echo 'selected'; ?> value="2">Reseller</option>
								</select>
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Status</label>
							<div class="col-sm-9 input-primary">
								<select name="status" class="default-select  form-control wide" required>
									<option <?php if ($value['status'] == '1')  echo 'selected'; ?> value="1"> Aktif </option>
									<option <?php if ($value['status'] == '2')   echo 'selected'; ?> value="2">Tidak aktif</option>
								</select>
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Kata Sandi</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="password" class="form-control" value="<?= $value['password'] ?>">
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
						<button type="submit" class="btn btn-primary">Edit user</button>
					</div>
					<?php echo form_close() ?>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--======UPDATE USER ENDS ======-->


	<!--======DELETE USER START ======-->
	<?php foreach ($user as $key => $value) { ?>
		<div class="modal fade" id="deleteUser<?= $value['idUser'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-body text-center">
						<div>
							<svg viewbox="0 0 24 24" width="80" height="80" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mb-2 text-warning"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
						</div>
						<h2>Apakah anda ingin menghapus user <strong><?= $value['nama'] ?></strong></h2>
						<div class="mt-4">
							<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
							<a href="<?= base_url('user/deleteData/' . $value['idUser']) ?>" class="btn btn-primary">Hapus</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--======DELETE USER ENDS ======-->


</div>


<?= $this->endSection() ?>