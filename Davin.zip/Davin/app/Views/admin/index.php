<?= $this->extend('template') ?>
<?= $this->section('content') ?>


<!--====== BAST SELLER START ======-->
Halaman dashboard
<!--====== BAST SELLER ENDS ======-->


<?= $this->endSection() ?>