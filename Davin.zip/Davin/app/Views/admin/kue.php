<?= $this->extend('template') ?>
<?= $this->section('content') ?>

<div class="row">


	<!--====== ALERT START ======-->
	<?php
	if (session()->getFlashdata('tambah')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('tambah');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('edit')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('edit');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	if (session()->getFlashdata('delete')) {
		echo'<div id="alert" class="alert alert-success alert-dismissible fade show">
		<svg viewbox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="me-2"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>	
		<strong>Berhasil!</strong>';
		echo session()->getFlashdata('delete');
		echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
		</button>
		</div>';
	}
	?>
	<!--====== ALERT ENDS ======-->


	<!--====== KUE START ======-->
	<div class="col-lg-12">
		<div class="card">
			<div class="row card-header">
				<div class="col-lg-6 col-6 mb-1 mt-1">
					<h4 class="card-title">Data <?= $subtitle ?></h4>
				</div>
				<div class="col-lg-6 col-6 text-end mb-1 mt-1">
					<button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addKue"><i class="fa fa-plus"></i> Tambah</button>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive-sm">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Kue</th>
								<th>Harga Toples Kecil</th>
								<th>Harga Toples Besar</th>
								<th>Aksis</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1;
							foreach ($kue as $key => $value) { ?>
								<tr>
									<th><?= $no++; ?></th>
									<td>
										<img alt="image" class="me-4 rounded" width="50" src="<?= base_url('images/kue/' . $value['fotoKue']) ?>">
										<?= $value['namaKue'] ?>
									</td>
									<td>Rp <?php echo number_format($value['hargaTk'], 0, ",","."); ?></td>
									<td>Rp <?php echo number_format($value['hargaTb'], 0, ",","."); ?></td>
									<td>
										<div class="d-flex">
											<button type="button" class="btn btn-success shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#updateKue<?= $value['idKue'] ?>"><i class="fas fa-pencil-alt"></i></button>
											<button type="button" class="btn btn-danger shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#deleteCake<?= $value['idKue'] ?>"><i class="fa fa-trash"></i></button>
										</div>	
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!--====== KUE ENDS ======-->


	<!--====== ADD KUE START ======-->
	<div class="modal fade" id="addKue">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Form tambah <?= $subtitle ?></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal">
					</button>
				</div>
				<?php echo form_open_multipart('kue/insertData') ?>
				<div class="modal-body">
					<div class="input-group mb-3 input-primary">
						<span class="btn btn-primary btn-sm">Foto Kue</span>
						<div class="form-file">
							<input type="file" name="fotoKue" class="form-file-input form-control">
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Nama Kue</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="namaKue" class="form-control" placeholder="Masukan nama pengguna." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Harga Toples Kecil</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="hargaTk" class="form-control" placeholder="Masukan nama lengkap." required>
						</div>
					</div>
					<div class="mb-3 row">
						<label class="col-sm-3 col-form-label">Harga Toples Besar</label>
						<div class="col-sm-9 input-primary">
							<input type="text" name="hargaTb" class="form-control" placeholder="Masukan nama lengkap." required>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
					<button type="submit" class="btn btn-primary">Tambah Kue</button>
				</div>
				<?php echo form_close() ?>
			</div>
		</div>
	</div>
	<!--====== ADD KUE ENDS ======-->


	<!--====== UPDATE KUE START ======-->
	<?php foreach ($kue as $key => $value) { ?>
		<div class="modal fade" id="updateKue<?= $value['idKue'] ?>">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Form Edit <?= $subtitle ?></h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal">
						</button>
					</div>
					<?php echo form_open_multipart('kue/updateData/' . $value['idKue']) ?>
					<div class="modal-body">
						<div class="m-2 text-center">
							<img src="<?= base_url('images/kue/' . $value['fotoKue']) ?>" height="150" width="150" class="rounded-circle object-fit">
						</div>
						<div class="input-group mb-3 input-primary">
							<span class="btn btn-primary btn-sm">Foto User</span>
							<div class="form-file">
								<input type="file" name="fotoKue" value="<?= base_url('images/user/' . $value['fotoKue']) ?>" class="form-file-input form-control">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Nama Kue</label>
							<div class="col-sm-9 input-primary">
								<input type="text" value="<?= $value['namaKue'] ?>" name="namaKue" class="form-control">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Harga Toples Kecil</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="hargaTk" class="form-control" value="<?= $value['hargaTk'] ?>">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-3 col-form-label">Harga Toples Besar</label>
							<div class="col-sm-9 input-primary">
								<input type="text" name="hargaTb" class="form-control" value="<?= $value['hargaTb'] ?>">
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
						<button type="submit" class="btn btn-primary">Edit Kue</button>
					</div>
					<?php echo form_close() ?>
				</div>
			</div>
		</div>
	<?php } ?>
	<!--====== UPDATE KUE ENDS ======-->


	<!--====== ADD KUE START ======-->
	<?php foreach ($kue as $key => $value) { ?>
			<div class="modal fade" id="deleteCake<?= $value['idKue'] ?>">
				<div class="modal-dialog modal-dialog-centered" role="document">
					<div class="modal-content">
						<div class="modal-body text-center">
							<div>
								<svg viewbox="0 0 24 24" width="80" height="80" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mb-2 text-warning"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
							</div>
							<h2>Apakah anda ingin menghapus kue <strong><?= $value['namaKue'] ?></strong></h2>
							<div class="mt-4">
								<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Batal</button>
								<a href="<?= base_url('kue/deleteData/' . $value['idKue']) ?>" class="btn btn-primary">Hapus</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	<!--====== ADD KUE ENDS ======-->


</div>


<?= $this->endSection() ?>