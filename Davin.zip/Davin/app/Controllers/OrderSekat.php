<?php

namespace App\Controllers;
use App\Models\ModelOrderSekat;
use App\Models\ModelKategori;

class OrderSekat extends BaseController
{
	public function __construct()
	{
		$this->ModelOrderSekat = new ModelOrderSekat();
		$this->ModelKategori = new ModelKategori();
		helper('form');

	}
	public function index(): string
	{
		$data = array(
			'title' => 'Davin cake & cookies',
			'subtitle' => 'Order Sekat',
			'orderSekat' => $this->ModelOrderSekat->getAllData(),
			'sekat' => $this->ModelKategori->sekat()
		);
		return view('reseller/orderSekat', $data);
	}
	public function insertData()
	{
		$data = [
			'idReseller' => $this->request->getPost('idReseller'),
			'nama' => $this->request->getPost('nama'),
			'idSekat' => $this->request->getPost('idSekat'),
			'alamat' => $this->request->getPost('alamat'),
			'noHp' => $this->request->getPost('noHp'),
			'status' => $this->request->getPost('status')
		];
		$this->ModelOrderSekat->insertData($data);
		session()->setFlashdata('tambah', ' berhasil di Order');
		return redirect()->to('orderSekat');
	}
	public function updateData($idOrder)
	{
		$data = [
			'idOrder' => $idOrder,
			'idReseller' => $this->request->getPost('idReseller'),
			'noOrder' => $this->request->getPost('noOrder'),
			'nama' => $this->request->getPost('nama'),
			'idSekat' => $this->request->getPost('idSekat'),
			'alamat' => $this->request->getPost('alamat'),
			'noHp' => $this->request->getPost('noHp'),
			'Status' => $this->request->getPost('Status')
		];
		$this->ModelOrderSekat->editData($data);
		session()->setFlashdata('edit', 'berhasil di edit');
		return redirect()->to('orderSekat');
	}
	public function deleteData($idOrder)
	{
		$order = $this->ModelOrderSekat->detailData($idOrder);
		$data = [
			'idOrder' => $idOrder,
		];
		$this->ModelOrderSekat->deleteData($data);
		session()->setFlashdata('delete', 'berhasil di hapus');
		return redirect()->to('orderSekat');
	}
}
