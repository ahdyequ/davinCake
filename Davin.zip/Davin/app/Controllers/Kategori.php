<?php

namespace App\Controllers;
use App\Models\ModelKategori;
use App\Models\ModelKue;

class Kategori extends BaseController
{
	public function __construct()
    {
        $this->ModelKategori = new ModelKategori();
        $this->ModelKue = new ModelKue();
        helper('form');
    }
    public function index(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Kategori',
            'bestSeller' => $this->ModelKategori->bestSeller(),
            'hampers' => $this->ModelKategori->hampers(),
            'sekat' => $this->ModelKategori->sekat(),
            'kue' => $this->ModelKue->kue()
        );
        return view('admin/kategori', $data);
    }


    // ====== BASTSELLER START ======
    public function insertBestSeller()
    {
        $idKue = $this->request->getPost('idKue');
        if (is_array($idKue)) {
            $jumlah = count($idKue);
            for ($i = 0; $i < $jumlah; $i++) {
                $currentIdKue = $idKue[$i];
                $this->ModelKategori->insertBestSeller([
                    'idKue' => $currentIdKue
                ]);
            }
            session()->setFlashdata('tambah', ' Best Seller berhasil ditambah');
            return redirect()->to('kategori');
        }
    }
    public function deleteBestSeller($idBestSeller)
    {
        $bestSeller = $this->ModelKategori->detailBestSeller($idBestSeller);
        $data = [
            'idBestSeller' => $idBestSeller,
        ];
        $this->ModelKategori->deleteBestSeller($data);
        session()->setFlashdata('delete', ' Best Seller berhasil di hapus');
        return redirect()->to('kategori');
    }
    // ====== BASTSELLER ENDS ======


    // ====== HAMPERS START ======
    public function insertHampers()
    {
        $data = [
            'kategori' => $this->request->getPost('kategori'),
            'jumlah' => $this->request->getPost('jumlah'),
            'massa' => $this->request->getPost('massa'),
            'harga' => $this->request->getPost('harga')
        ];
        $this->ModelKategori->insertHampers($data);
        session()->setFlashdata('tambah', ' Hampers berhasil ditambah');
        return redirect()->to('kategori');
    }
    public function updateHampers($idHampers)
    {
        $hampers = $this->ModelKategori->detailHampers($idHampers);
        $data = [
            'idHampers' => $idHampers,
            'kategori' => $this->request->getPost('kategori'),
            'jumlah' => $this->request->getPost('jumlah'),
            'massa' => $this->request->getPost('massa'),
            'harga' => $this->request->getPost('harga')
        ];
        $this->ModelKategori->updateHampers($data);
        session()->setFlashdata('edit', ' Hampers berhasil di ubah');
        return redirect()->to('kategori');
    }
    public function deleteHampers($idHampers)
    {
        $hampers = $this->ModelKategori->detailHampers($idHampers);
        $data = [
            'idHampers' => $idHampers,
        ];
        $this->ModelKategori->deleteHampers($data);
        session()->setFlashdata('delete', ' Hampers berhasil di hapus');
        return redirect()->to('kategori');
    }
    // ====== HAMPERS ENDS ======


    // ====== SEKAT START ======
    public function insertSekat()
    {
        $data = [
            'kategori' => $this->request->getPost('kategori'),
            'namaKue' => implode(",", $this->request->getPost('namaKue')),
            'harga' => $this->request->getPost('harga')
        ];
        $this->ModelKategori->insertSekat($data);
        session()->setFlashdata('tambah', ' Sekat berhasil di tambah');
        return redirect()->to('kategori');
    }
    public function updateSekat($idSekat)
    {
        $sekat = $this->ModelKategori->detailSekat($idSekat);
        $data = [
            'idSekat' => $idSekat,
            'kategori' => $this->request->getPost('kategori'),
            'namaKue' => implode(",", $this->request->getPost('namaKue[]')),
            'harga' => $this->request->getPost('harga')
        ];
        $this->ModelKategori->updateSekat($data);
        session()->setFlashdata('edit', ' Sekat berhasil di ubah');
        return redirect()->to('kategori');
    }
    public function deleteSekat($idSekat)
    {
        $sekat = $this->ModelKategori->detailSekat($idSekat);
        $data = [
            'idSekat' => $idSekat,
        ];
        $this->ModelKategori->deleteSekat($data);
        session()->setFlashdata('delete', ' Sekat berhasil di hapus');
        return redirect()->to('kategori');
    }
    // ====== HAMPERS ENDS ======
}
