<?php

namespace App\Controllers;
use App\Models\ModelKue;

class Kue extends BaseController
{
    public function __construct()
    {
        $this->ModelKue = new ModelKue();
        helper('form');

    }
    public function index(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Kue',
            'kue' => $this->ModelKue->kue()
        );
        return view('admin/kue', $data);
    }
    public function insertData()
    {
        $file = $this->request->getFile('fotoKue');
        $nama_file = $file->getRandomName();
        $data = [
            'namaKue' => $this->request->getPost('namaKue'),
            'hargaTk' => $this->request->getPost('hargaTk'),
            'hargaTb' => $this->request->getPost('hargaTb'),
            'fotoKue' => $nama_file
        ];
        $file->move('images/kue', $nama_file);
        $this->ModelKue->insertData($data);
        session()->setFlashdata('tambah', ' Kue berhasil di tambah');
        return redirect()->to('kue');
    }
    public function updateData($idKue)
    {
        $file = $this->request->getFile('fotoKue');
        if ($file->getError() == 4) {
            $data = [
                'idKue' => $idKue,
                'namaKue' => $this->request->getPost('namaKue'),
                'hargaTk' => $this->request->getPost('hargaTk'),
                'hargaTb' => $this->request->getPost('hargaTb')
            ];
            $this->ModelKue->editData($data);
        } else {
            helper('filesystem');
            $kue = $this->ModelKue->detailData($idKue);
            if ($kue['fotoKue'] != ""){
                unlink('./images/kue/' . $kue['fotoKue']);
            }
            $nama_file = $file->getRandomName();
            $data = [
                'idKue' => $idKue,
                'namaKue' => $this->request->getPost('namaKue'),
                'hargaTk' => $this->request->getPost('hargaTk'),
                'hargaTb' => $this->request->getPost('hargaTb'),
                'fotoKue' => $nama_file
            ];
            $file->move('images/kue', $nama_file);
            $this->ModelKue->editData($data);
        }
        session()->setFlashdata('edit', ' Kue berhasil di edit');
        return redirect()->to('kue');
    }
    public function deleteData($idKue)
    {
        $kue = $this->ModelKue->detailData($idKue);
        $data = [
            'idKue' => $idKue,
        ];
        $this->ModelKue->deleteData($data);
        session()->setFlashdata('delete', ' Kue berhasil di hapus');
        return redirect()->to('kue');
    }
}