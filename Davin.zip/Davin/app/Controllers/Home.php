<?php

namespace App\Controllers;
use App\Models\ModelInterfaces;

class Home extends BaseController
{
    public function __construct()
    {
        $this->ModelInterfaces = new ModelInterfaces();
        helper('form');
    }
    public function index(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Home',
            'bestSeller' => $this->ModelInterfaces->bestSeller(),
            'kue' => $this->ModelInterfaces->kue(),
            'kontak' => $this->ModelInterfaces->kontak()
        );
        return view('intervaces/index', $data);
    }
    public function bestSeller(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Best Seller',
            'bestSeller' => $this->ModelInterfaces->bestSellerNoLimit()
        );
        return view('intervaces/bestSeller', $data);
    }
    public function allKue(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Semua Kue',
            'allKue' => $this->ModelInterfaces->kueNoLimit()
        );
        return view('intervaces/allKue', $data);
    }
}
