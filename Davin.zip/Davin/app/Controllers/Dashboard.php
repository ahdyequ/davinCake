<?php

namespace App\Controllers;
use App\Models\ModelInterfaces;

class Dashboard extends BaseController
{
    public function index(): string
    {
        $data = array(
            'title' => 'Davin cake & cookies',
            'subtitle' => 'Dashboard'
        );
        return view('admin/index', $data);
    }
}
