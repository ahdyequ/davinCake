<?php

namespace App\Controllers;
use App\Models\ModelUser;

class User extends BaseController
{
	public function __construct()
	{
		$this->ModelUser = new ModelUser();
		helper('form');

	}
	public function index(): string
	{
		$data = array(
			'title' => 'Davin cake & cookies',
			'subtitle' => 'User',
			'user' => $this->ModelUser->getAllData()
		);
		return view('admin/user', $data);
	}
	public function insertData()
	{
		$file = $this->request->getFile('fotoUser');
		$nama_file = $file->getRandomName();
		$data = [
			'namaPengguna' => $this->request->getPost('namaPengguna'),
			'nama' => $this->request->getPost('nama'),
			'email' => $this->request->getPost('email'),
			'password' => $this->request->getPost('password'),
			'level' => $this->request->getPost('level'),
			'status' => $this->request->getPost('status'),
			'fotoUser' => $nama_file
		];
		$file->move('images/user', $nama_file);
		$this->ModelUser->insertData($data);
		session()->setFlashdata('tambah', ' User berhasil di tambah');
		return redirect()->to('user');
	}
	public function updateData($idUser)
	{
		$file = $this->request->getFile('fotoUser');
		if ($file->getError() == 4) {
			$data = [
				'idUser' => $idUser,
				'namaPengguna' => $this->request->getPost('namaPengguna'),
				'nama' => $this->request->getPost('nama'),
				'email' => $this->request->getPost('email'),
				'password' => $this->request->getPost('password'),
				'level' => $this->request->getPost('level'),
				'status' => $this->request->getPost('status')
			];
			$this->ModelUser->editData($data);
		}else{
			helper('filesystem');
			$user = $this->ModelUser->detailData($idUser);
			if ($user['fotoUser'] != ""){
				unlink('./images/user/' . $user['fotoUser']);
			}
			$nama_file = $file->getRandomName();
			$data = [
				'idUser' => $idUser,
				'namaPengguna' => $this->request->getPost('namaPengguna'),
				'nama' => $this->request->getPost('nama'),
				'email' => $this->request->getPost('email'),
				'password' => $this->request->getPost('password'),
				'level' => $this->request->getPost('level'),
				'status' => $this->request->getPost('status'),
				'fotoUser' => $nama_file
			];
			$file->move('images/user', $nama_file);
			$this->ModelUser->editData($data);
		}
		session()->setFlashdata('edit', ' User berhasil di edit');
		return redirect()->to('user');
	}
	public function deleteData($idUser)
	{
		$user = $this->ModelUser->detailData($idUser);
		if ($user['fotoUser'] != ""){
			unlink('./images/user/' . $user['fotoUser']);
		}
		$data = [
			'idUser' => $idUser,
		];
		$this->ModelUser->deleteData($data);
		session()->setFlashdata('delete', ' User berhasil di hapus');
		return redirect()->to('user');
	}
}
